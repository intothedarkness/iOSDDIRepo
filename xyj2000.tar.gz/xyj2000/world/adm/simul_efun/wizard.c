// cracked by vikee 2/09/2002   vikee@263.net
// wiz.c

int wiz_level(mixed ob)
{
	return SECURITY_D->get_wiz_level(ob);
}

string wizhood(mixed ob)
{
	return SECURITY_D->get_status(ob);
}

/*void disable_commands( )
{
   if( this_player()->query("id") != "tool" )
      efun::disable_commands();
}
*/
