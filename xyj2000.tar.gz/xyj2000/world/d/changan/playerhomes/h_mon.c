// cracked by vikee 2/09/2002   vikee@263.net
// home for mon.

//inherit "/d/changan/playerhomes/home.c";
inherit "/obj/home.c";

void create()
{
     ::create();
     restore();
     setup();
}

