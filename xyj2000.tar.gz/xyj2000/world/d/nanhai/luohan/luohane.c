// cracked by vikee 2/09/2002   vikee@263.net
inherit ROOM;

void create ()
{
  set ("short", "�޺���");
  set ("long", @LONG


			��


LONG);


  set("exits", ([ /* sizeof() == 4 */
  "down" : __DIR__"luohane9",
]));

	set("jingzuo_room", 1);

  setup();
}
