// cracked by vikee 2/09/2002   vikee@263.net
// wugang.c

inherit NPC;

void create()
{
        set_name("���", ({"wu gang","wugang","wu","gang"}));
        set("gender", "����" );
        set("age", 35);
        set("long", "һ��������Ĵ󺺣�");
        set("combat_exp", 100000);
  set("daoxing", 300000);

        set("attitude", "peaceful");

        set("eff_dx", 40000);
        set("nkgain", 200);

        set_skill("unarmed", 50);
        set_skill("dodge", 50);
        set_skill("parry", 80);
        set_skill("literate", 50);
        set_skill("force", 50);   
        set_skill("axe", 100);
        set("per", 27);
        set("max_kee", 500);
        set("max_gin", 200);
        set("max_sen", 300);
        set("force", 450);
        set("max_force", 300);
        set("force_factor", 15);
        setup();
        carry_object("/d/ourhome/obj/linen")->wear();
        carry_object("/d/moon/obj/bigaxe")->wield();
}

int accept_fight(object me)
{
        command("jump");     
        command("say ���ã��ҿ��˰�������Ҳ�û����ˡ�");
        return 1;
}