// cracked by vikee 2/09/2002   vikee@263.net
#include <ansi.h>

inherit "/d/dntg/laojunlu/laojunlu.c";

void create()
{
  ::create();
  set("short", "Ǭ��");
}

