// cracked by vikee 2/09/2002   vikee@263.net
// Room: /d/sky/nantianmen
 
#include <room.h>
#include <ansi.h>
inherit ROOM;


void create ()
{
  set ("short", "�����");
  set ("long", @LONG


LONG);

  set("exits", ([ /* sizeof() == 3 */
  "east"      : __DIR__"yunlue1",
  "west"      : __DIR__"tongmingdian",

]));




  setup();
}
 
