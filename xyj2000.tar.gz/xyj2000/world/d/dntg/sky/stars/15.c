// cracked by vikee 2/09/2002   vikee@263.net
#define ID 15
#include <star.c>
