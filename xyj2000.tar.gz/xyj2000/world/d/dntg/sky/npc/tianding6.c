// cracked by vikee 2/09/2002   vikee@263.net
#include <ansi.h>

inherit "/d/dntg/sky/npc/tianding.c";

void create()
{
  ::create();
  set_name("����Ȫ",({ "xin jiu quan", "tian ding", "ding","tianding" }) );

}
