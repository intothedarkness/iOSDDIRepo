// cracked by vikee 2/09/2002   vikee@263.net
#include <ansi.h>

inherit "/d/dntg/sky/npc/tianding.c";

void create()
{
  ::create();
  set_name("������",({ "liu wan qi", "tian ding", "ding","tianding" }) );

}
