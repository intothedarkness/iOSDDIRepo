// cracked by vikee 2/09/2002   vikee@263.net
inherit NPC;

void create()
{
	set_name("�η�ɮ��", ({"seng ren","seng"}));
	set("long", "һλ�η����У�����������ϵ����Ĵ����˲�����\n");

	set("gender", "����");
	set("attitude", "friendly");
	set("class", "bonze");

	set("age", 30+random(20));
	set("shen_type", 1);
	set("str", 20);
	set("int", 30);
	set("con", 25);
	set("dex", 23);
	set("max_kee", 380);
	set("max_gin", 300);
	set("combat_exp", 10000+random(30000));
  set("daoxing", 50000);


	set("chat_chance", 40);
        set("chat_msg", ({
		(: random_move :)
	}));


	set_skill("force", 30+random(40));
	set_skill("unarmed", 30+random(40));
	set_skill("dodge", 30+random(40));
	set_skill("parry", 30+random(40));

	setup();
	carry_object("/d/obj/cloth/sengyi")->wear();

	setup();
}

�