// cracked by vikee 2/09/2002   vikee@263.net
// magic.c

inherit SKILL;

string type() { return "knowledge"; }
