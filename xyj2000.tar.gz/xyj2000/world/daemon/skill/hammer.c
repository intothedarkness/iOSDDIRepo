// cracked by vikee 2/09/2002   vikee@263.net
// hammer.c

inherit SKILL;
