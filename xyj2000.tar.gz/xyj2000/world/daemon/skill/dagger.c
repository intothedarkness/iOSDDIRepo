// cracked by vikee 2/09/2002   vikee@263.net
// sword.c

inherit SKILL;
