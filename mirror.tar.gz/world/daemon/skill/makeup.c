//Cracked by Roath
inherit SKILL;

string type() { return "knowledge"; }
