//Cracked by Roath
// spear.c

inherit SKILL;
