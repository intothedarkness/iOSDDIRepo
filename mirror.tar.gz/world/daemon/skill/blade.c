//Cracked by Roath
// blade.c

inherit SKILL;

