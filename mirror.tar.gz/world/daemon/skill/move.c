//Cracked by Roath
// move.c

inherit SKILL;
