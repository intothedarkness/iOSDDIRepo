//Cracked by Roath
// magic.c

inherit SKILL;

string type() { return "knowledge"; }
