#ifndef __NET__CONFIG_H
#define __NET__CONFIG_H

#ifndef SVC_TCP
#include <net/services.h>
#endif

/* These are the primary and secondry hosts to use as boot servers
 * for the DNS.  It is better to set to the primary to be a mud on
 * the same continent.
 */
// 11-1-95
// ES
#define MUDLIST_DNS ({ "202.96.134.136", 3991 })
// enchanted rock

#define MUDLIST_BAK ({ "202.96.134.136", 4004 })


#define LISTNODES ([ \
"jhfy" : "61.128.193.47 8892",\
  "xyj" : "202.100.42.46 6670",\
"dhxy-qd" : "203.93.95.159 6670",\
"dhxy-hn" : "202.110.102.97 6670 " ,\
"happy" : "202.117.7.54 6670",\
"dreamxyj" : "202.102.14.25 6670",\
"xyj2000": "61.128.193.112 2004",\
"djx" : "61.128.193.112 5559",\
"xyj": "202.100.42.46 6670", \
"DJX.XA" : "202.100.8.28 5559",\
"sdyx" : "202.103.225.69 2004",\
"J.H.Y.J" : "61.139.77.49 6672",\
"ldj.wuhan" : "202.103.25.171 4004",\
"ldj.xa" : "202.100.30.11 4448",\
"BUCT" : "202.4.143.155 5559",\
"XAJH2.EAST" : "202.96.125.121 4004",\
"XAJH2" : "202.96.134.136 4004",\
"XKX" : "203.71.88.137 6670",\
"gy" : "202.98.193.241 6670", \
"shxyj" : "202.96.236.99 6670", \
"xbsk" : "202.100.72.21 6670",\
"qd" : "203.93.95.127 6670", \
 "bj" : "61.151.243.134 6670",\
"hangzhou" : "10.103.68.165 6670", \
"sy": "202.118.29.99 6670", \
 "xa": "61.134.4.61 6670", \
"xm": "202.101.104.234 6670", \
"zz": "202.102.245.25 6670", \
"sz": "202.102.14.189 6670", \
"cs": "202.103.111.170 6670", \
])

/* These IP are not welcome
 * add by ken@chinesemud.net
 */
#define BANDLIST ([\
"dtxy" : "61.134.12.112 2004" ,\
"ys.bj" : "210.77.145.223",\
"xhc" : "202.96.144.141 5559",\
"jxqy" : "61.139.29.94 6670" ,\
])

/* This is the default packet size of outgoing mail messages.  The ideal
 * number is 512, maximum would be about 900, since 1024 is the maximum
 * udp packet size.  Probably best kept at 512
 */
 
#define MAIL_PACKET_SIZE        512
 
/* These macros are for the name service.  They determine how often the
 * database is refreshed, how often other muds are checked, how often
 * the sequence list is checked for timed out services, and how long a
 * service is allowed to time out.
 */
#define REFRESH_INTERVAL     5*60
#define PING_INTERVAL       30*60
#define SEQ_CLEAN_INTERVAL  60*60
#define SERVICE_TIMEOUT        30

/* The number of muds that we initialy allocate space for.  This speeds
 * up name lookup.
 */
#define MUDS_ALLOC 60

/* This macro controls the level of tcp support used by the mud for
 * services such as finger, tell and mail. Valid values are:
 *  TCP_ALL   - all services available
 *  TCP_ONLY  - only tcp services available
 *  TCP_SOME  - some tcp services are available
 *  TCP_NONE  - no tcp services available
 */
#define TCP_SERVICE_LEVEL TCP_ALL

/* These are the prefered protocols used for certain services which can
 * be done either way.  Mail should be left tcp, the others are up to
 * the individual admin.  If the one you choose is not supported the
 * other type _may_ be used depending on the service.
 */

#define PREF_MAIL         SVC_TCP
#define PREF_FINGER       SVC_TCP
#define PREF_TELL         SVC_UDP

/* These macros are used by the name server to keep a list of muds which
 * do not support the DNS.
 */
#define MUD_ADDRESSES   "/adm/etc/mud_addresses"
#define MUD_SERVICES    "/adm/etc/mud_services"

/* These IP are for Big5 chinese codes 
 * add by ken@chinesemud.net
 */
#define Big5IP ({ "140","192","207","209","203", "210", "129", "208", "205", "206" })

#endif //__NET__CONFIG_H

