//Cracked by Roath
#include <net/dns.h>
#include <net/daemons.h>

int main()
{
	mapping mud_info;
	mud_info = 	DNS_MASTER->query_mud_info("sz");

	mud_info["HOSTADDRESS"] = "61.151.243.134";
	mud_info["NAME"] = "bj";
	mud_info["MUDNAME"] = "���μǱ���վ";
	mud_info["ALIAS"] = "bj";

	DNS_MASTER->set_mud_info("bj",mud_info);
	return 1;
}
