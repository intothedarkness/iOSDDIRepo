//Cracked by Roath
// ping.c
// created by vikee.
// 2004.4.20


#include <net/dns.h>
#include <net/macros.h>

inherit F_CLEAN_UP;
inherit F_DBASE;

int main( object me, string host, string port )
{
	CHANNEL_D->do_channel( me, "sys", "send ping message to" +  host + " "+port+" (from "+Mud_name()+")");        
	// PING_Q->send_ping_q(host, port);
	DNS_MASTER->send_udp(host, port, "@@@"+DNS_PING_Q+
		"||NAME:"+Mud_name()+
		"||PORTUDP:"+udp_port()+
		"@@@\n");

	return 1;	
}