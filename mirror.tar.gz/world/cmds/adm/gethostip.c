//Cracked by Roath
 // ping.c
// created by vikee.
// 2004.4.20


#include <socket_err.h>
#include <net/daemons.h>
#include <net/dns.h>
#include <net/socket.h>
#include <net/services.h>
#include <net/macros.h>

inherit F_CLEAN_UP;
inherit F_DBASE;

int main( object me, string host )
{

	string IP = socket_address(this_object());
	write( IP + "\n" );	
	return 1;	
}