//Cracked by Roath
inherit __DIR__"bobing";

void create()
{
    ::create();
    set("exits",
        ([
          "south":__DIR__"bobing1",]));
}
