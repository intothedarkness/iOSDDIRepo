//Cracked by Roath
inherit __DIR__"bobing";

void create()
{
    ::create();
    set("exits",
        (["north":__DIR__"bobing2",
          "south":__DIR__"bobing",]));
}
