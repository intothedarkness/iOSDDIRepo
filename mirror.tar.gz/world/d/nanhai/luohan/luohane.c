//Cracked by Roath
inherit ROOM;

void create ()
{
  set ("short", "�޺���");
  set ("long", @LONG


			��


LONG);


  set("exits", ([ /* sizeof() == 4 */
  "down" : __DIR__"luohane9",
]));

	set("jingzuo_room", 1);

  setup();
}
