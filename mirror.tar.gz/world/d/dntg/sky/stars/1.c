//Cracked by Roath
#define ID 1
#include <star.c>
