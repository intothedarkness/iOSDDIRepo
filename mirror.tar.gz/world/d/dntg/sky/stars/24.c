//Cracked by Roath
#define ID 24
#include <star.c>
