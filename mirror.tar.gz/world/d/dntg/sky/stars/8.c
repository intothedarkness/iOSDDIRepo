//Cracked by Roath
#define ID 8
#include <star.c>
