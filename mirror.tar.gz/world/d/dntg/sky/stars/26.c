//Cracked by Roath
#define ID 26
#include <star.c>
