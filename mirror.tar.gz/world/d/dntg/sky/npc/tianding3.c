//Cracked by Roath
#include <ansi.h>

inherit "/d/dntg/sky/npc/tianding.c";

void create()
{
  ::create();
  set_name("������",({ "gou yun yang", "tian ding", "ding","tianding" }) );

}
