//Cracked by Roath
#include <ansi.h>

inherit "/d/dntg/sky/npc/tianding.c";

void create()
{
  ::create();
  set_name("�ӽ���",({ "pang jin ge", "tian ding", "ding","tianding" }) );

}
