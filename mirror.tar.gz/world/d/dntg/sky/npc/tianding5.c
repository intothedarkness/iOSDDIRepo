//Cracked by Roath
#include <ansi.h>

inherit "/d/dntg/sky/npc/tianding.c";

void create()
{
  ::create();
  set_name("�˹���",({ "deng guo yan", "tian ding", "ding","tianding" }) );

}
