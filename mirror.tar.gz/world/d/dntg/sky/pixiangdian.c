//Cracked by Roath
//sgzl

#include <room.h>
inherit ROOM;

void create()
{
set("short", "�����");
set("long", @LONG
    
LONG );


set("exits", ([
  "west"   : __DIR__"taiyanggong",
]));


set("objects", ([
]));



setup();
}
