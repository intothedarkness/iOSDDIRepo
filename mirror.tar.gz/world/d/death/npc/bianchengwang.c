//Cracked by Roath
//puti.c
//inherit NPC;
inherit "/d/dntg/hell/wang.c";

void create()
{
       set_name("�����", ({"biancheng wang", "wang"}));
       set("title", "����ʮ��֮");
       set("gender", "����");
	set("class", "youling");
       set("age", 50);
       set("attitude", "friendly");
       set("per", 30);
        set("int", 30);

        set("max_kee", 1600);
        set("max_gin", 1600);
        set("max_sen", 1600);
        set("force", 1500);
        set("max_force", 1500);
        set("force_factor", 50);
        set("max_mana", 1500);
        set("mana", 1500);
        set("mana_factor", 50);
        set("combat_exp", 1500000);
        set("daoxing", 2000000);

        set("eff_dx", 600000);
        set("nkgain", 600);

        set_skill("spells", 150);
        set_skill("gouhunshu", 150);
        set_skill("unarmed", 150);
        set_skill("dodge", 150);
        set_skill("parry", 150);
        set_skill("force", 150);
        set_skill("tonsillit", 150);
        set_skill("jinghun-zhang", 150);
        set_skill("ghost-steps", 150);
        map_skill("unarmed", "jinghun-zhang");
        map_skill("dodge", "ghost-steps");
        map_skill("spells", "gouhunshu");
        map_skill("force", "tonsillit");

        set("chat_chance_combat", 40);
        set("chat_msg_combat", ({
                (: cast_spell, "invocation" :),
                (: cast_spell, "curse" :),
                (: cast_spell, "inferno" :)
        }) );

setup();

        carry_object("/d/obj/cloth/mangpao")->wear();
}

�
